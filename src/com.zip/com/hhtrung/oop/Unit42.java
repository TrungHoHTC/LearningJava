package com.hhtrung.oop;

public class Unit42 {
}
