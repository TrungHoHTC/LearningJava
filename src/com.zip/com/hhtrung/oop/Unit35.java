package com.hhtrung.oop;

import java.io.IOException;

public class Unit35 extends Tutorial35 {
    public static void main(String[] args) {
        Unit35 u = new Unit35();
        u.show();

    }

    public void show(){
        System.out.println("show in Unit 35");

    }
}

class Tutorial35 {
    public void show() {
        System.out.println("show in Tutorial");
    }
}

