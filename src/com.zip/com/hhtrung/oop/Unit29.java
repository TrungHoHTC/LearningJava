package com.hhtrung.oop;

import com.hhtrung.basic.ForDemo;

public class Unit29 {
    public static void main(String[] args) {
        //this will import the class ForDemo from package basic.
        ForDemo fn=new ForDemo();
    }

}
